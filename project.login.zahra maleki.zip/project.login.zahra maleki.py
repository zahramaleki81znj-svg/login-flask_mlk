from flask import Flask, request, redirect, url_for, session, render_template_string
import sqlite3
import os
from google_auth_oauthlib.flow import Flow
from google.oauth2 import id_token
import google.auth.transport.requests

app = Flask(__name__)
app.secret_key = "CHANGE_THIS_SECRET_KEY"

DB_NAME = "users.db"
GOOGLE_CLIENT_ID = "871689565112-rql81hi823lsihcsvfe7aqcoqb8tf096.apps.googleusercontent.com"
GOOGLE_CLIENT_SECRET = "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"
os.environ["OAUTHLIB_INSECURE_TRANSPORT"] = "1"

# =========================
# بخش استایل (همان کدی که قبلاً گذاشتی)
# =========================
common_css = """
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
<style>
    @import url('https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;700&display=swap');
    * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Vazirmatn', sans-serif; }
    body {
        display: flex; justify-content: center; align-items: center; min-height: 100vh;
        background: radial-gradient(circle at center, #1a1a2e 0%, #0f0f1b 100%);
        color: #fff; overflow-x: hidden;
    }
    .background { width: 430px; height: 520px; position: absolute; transform: translate(-50%,-50%); left: 50%; top: 50%; z-index: -1; }
    .background .shape { height: 200px; width: 200px; position: absolute; border-radius: 50%; filter: blur(80px); opacity: 0.4; }
    .shape:first-child { background: #1845ad; left: -80px; top: -80px; }
    .shape:last-child { background: #ff512f; right: -30px; bottom: -80px; }
    .container {
        width: 400px; background: rgba(255, 255, 255, 0.05); backdrop-filter: blur(15px);
        border-radius: 20px; border: 1px solid rgba(255, 255, 255, 0.1);
        padding: 40px; box-shadow: 0 25px 50px rgba(0,0,0,0.5); text-align: center;
    }
    h3 { font-size: 28px; margin-bottom: 20px; color: #fff; }
    label { display: block; text-align: right; margin-top: 15px; font-size: 14px; color: #ccc; }
    input {
        width: 100%; height: 45px; margin-top: 8px; background: rgba(255,255,255,0.1);
        border: none; border-radius: 8px; padding: 10px; color: #fff; outline: none; transition: 0.3s; text-align: right;
    }
    button, .btn {
        margin-top: 25px; width: 100%; padding: 12px; border: none; border-radius: 8px;
        background: #fff; color: #000; font-weight: 700; cursor: pointer; transition: 0.3s;
        display: block; text-decoration: none; text-align: center;
    }
    .google-btn { margin-top: 15px; background: #db4437; color: #fff; display: flex; align-items: center; justify-content: center; gap: 10px; }
    .links { margin-top: 20px; display: flex; justify-content: space-between; font-size: 13px; }
    .links a { color: #00d2ff; text-decoration: none; }
    table { width: 100%; border-collapse: collapse; margin-top: 20px; color: #fff; direction: rtl; }
    th { background: rgba(255,255,255,0.1); padding: 12px; text-align: center; color: #00d2ff; }
    td { padding: 10px; border-bottom: 1px solid rgba(255,255,255,0.05); text-align: center; }
</style>
"""

# =========================
# HTML ها
# =========================
login_html = common_css + """
<div class="background"><div class="shape"></div><div class="shape"></div></div>
<div class="container">
    <form method="POST">
        <h3>ورود</h3>
        {% if error %}<p style="color:#ff512f; font-size:14px;">{{error}}</p>{% endif %}
        <label>ایمیل</label>
        <input name="email" type="email" required placeholder="email@example.com">
        <label>رمز عبور</label>
        <input name="password" type="password" required placeholder="••••••••">
        <button type="submit">وارد شوید</button>
        <a class="btn google-btn" href="/google-login">
            <i class="fab fa-google"></i> ورود با گوگل
        </a>
        <div class="links">
            <a href="/register">ثبت نام</a>
            <a href="#">فراموشی رمز؟</a>
        </div>
    </form>
</div>
"""

register_html = common_css + """
<div class="background"><div class="shape"></div><div class="shape"></div></div>
<div class="container" style="width: 450px;">
    <form method="POST">
        <h3>ثبت نام کاربر</h3>
        {% if error %}<p style="color:#ff512f;">{{error}}</p>{% endif %}
        <label>ایمیل</label>
        <input name="email" type="email" required>
        <div style="display:flex; gap:10px;">
            <div style="flex:1;"><label>نام</label><input name="firstname" type="text" required></div>
            <div style="flex:1;"><label>نام خانوادگی</label><input name="lastname" type="text" required></div>
        </div>
        <label>آدرس</label>
        <input name="address" type="text">
        <label>کد شهر</label>
        <input name="zipcode" type="text">
        <label>رمز عبور</label>
        <input name="password" type="password" required>
        <button type="submit">ثبت اطلاعات</button>
        <div class="links" style="justify-content:center; margin-top:15px;">
            <a href="/">بازگشت به ورود</a>
        </div>
    </form>
</div>
"""

dashboard_html = common_css + """
<div class="background"><div class="shape"></div><div class="shape"></div></div>
<div class="container" style="width: 90%; max-width: 900px;">
    <h3>داشبورد مدیریت</h3>
    <p style="margin-bottom:10px;">وارد شده با: <b style="color:#00d2ff;">{{email}}</b></p>
    <hr style="opacity:0.1;">
    <table>
        <thead>
            <tr>
                <th>شناسه</th>
                <th>ایمیل</th>
                <th>نام</th>
                <th>نام خانوادگی</th>
                <th>آدرس</th>
            </tr>
        </thead>
        <tbody>
            {% for user in users %}
            <tr>
                <td>{{ user[0] }}</td>
                <td>{{ user[1] }}</td>
                <td>{{ user[2] }}</td>
                <td>{{ user[3] }}</td>
                <td>{{ user[4] or '---' }}</td>
            </tr>
            {% endfor %}
        </tbody>
    </table>
    <a href="/logout" class="btn" style="background:#ff512f; color:#fff; width:120px; margin: 30px auto 0;">خروج</a>
</div>
"""

# =========================
# دیتابیس
# =========================
def init_db():
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("CREATE TABLE IF NOT EXISTS role (RoleId INTEGER PRIMARY KEY, Rolename TEXT UNIQUE NOT NULL)")
    c.execute("CREATE TABLE IF NOT EXISTS city (Zipcode TEXT PRIMARY KEY, City TEXT NOT NULL)")
    c.execute("""CREATE TABLE IF NOT EXISTS users (
        UserId INTEGER PRIMARY KEY AUTOINCREMENT,
        Email TEXT UNIQUE NOT NULL,
        Firstname TEXT NOT NULL,
        Lastname TEXT NOT NULL,
        Address TEXT,
        UserZipcode TEXT,
        UserRole INTEGER,
        Password TEXT,
        FOREIGN KEY (UserRole) REFERENCES role(RoleId),
        FOREIGN KEY (UserZipcode) REFERENCES city(Zipcode)
    )""")
    c.execute("INSERT OR IGNORE INTO role VALUES (1,'Admin'),(2,'User')")
    c.execute("INSERT OR IGNORE INTO city VALUES ('12345','Tehran'),('67890','Isfahan')")
    conn.commit()
    conn.close()

init_db()

# =========================
# Routes اصلی
# =========================
@app.route("/", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email")
        password = request.form.get("password")
        conn = sqlite3.connect(DB_NAME)
        c = conn.cursor()
        c.execute("SELECT * FROM users WHERE Email=? AND Password=?", (email, password))
        user = c.fetchone()
        conn.close()
        if not user:
            return render_template_string(login_html, error="ایمیل یا رمز عبور اشتباه است")
        session["email"] = email
        return redirect("/dashboard")
    return render_template_string(login_html)

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        email = request.form.get("email")
        firstname = request.form.get("firstname")
        lastname = request.form.get("lastname")
        address = request.form.get("address")
        zipcode = request.form.get("zipcode")
        password = request.form.get("password")
        try:
            conn = sqlite3.connect(DB_NAME)
            c = conn.cursor()
            c.execute("INSERT INTO users (Email, Firstname, Lastname, Address, UserZipcode, UserRole, Password) VALUES (?, ?, ?, ?, ?, ?, ?)",
                      (email, firstname, lastname, address, zipcode, 2, password))
            conn.commit()
            conn.close()
            return redirect("/")
        except:
            return render_template_string(register_html, error="این ایمیل قبلاً ثبت شده است")
    return render_template_string(register_html)

@app.route("/dashboard")
def dashboard():
    if "email" not in session: return redirect("/")
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("SELECT UserId, Email, Firstname, Lastname, Address FROM users")
    user_list = c.fetchall()
    conn.close()
    return render_template_string(dashboard_html, email=session["email"], users=user_list)

@app.route("/logout")
def logout():
    session.clear()
    return redirect("/")

# =========================
# Google OAuth اصلاح شده
# =========================
@app.route("/google-login")
def google_login():
    flow = Flow.from_client_config(
        {"web": {"client_id": GOOGLE_CLIENT_ID,
                 "client_secret": GOOGLE_CLIENT_SECRET,
                 "auth_uri": "https://accounts.google.com/o/oauth2/auth",
                 "token_uri": "https://oauth2.googleapis.com/token",
                 "redirect_uris": ["http://127.0.0.1:5000/google-callback"]}},
        scopes=["openid", "email", "profile"]
    )
    flow.redirect_uri = "http://127.0.0.1:5000/google-callback"  # 🔹 اضافه شده
    authorization_url, state = flow.authorization_url(prompt="consent")
    session["state"] = state
    return redirect(authorization_url)

@app.route("/google-callback")
def google_callback():
    flow = Flow.from_client_config(
        {"web": {"client_id": GOOGLE_CLIENT_ID,
                 "client_secret": GOOGLE_CLIENT_SECRET,
                 "auth_uri": "https://accounts.google.com/o/oauth2/auth",
                 "token_uri": "https://oauth2.googleapis.com/token",
                 "redirect_uris": ["http://127.0.0.1:5000/google-callback"]}},
        scopes=["openid", "email", "profile"],
        state=session.get("state")  # 🔹 ایمن تر
    )
    flow.redirect_uri = "http://127.0.0.1:5000/google-callback"  # 🔹 اضافه شده
    flow.fetch_token(authorization_response=request.url)
    idinfo = id_token.verify_oauth2_token(
        flow.credentials._id_token,
        google.auth.transport.requests.Request(),
        GOOGLE_CLIENT_ID
    )

    email = idinfo["email"]
    name = idinfo.get("name", "User").split(" ")

    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE Email=?", (email,))
    if not c.fetchone():
        c.execute(
            "INSERT INTO users (Email, Firstname, Lastname, UserRole) VALUES (?,?,?,2)",
            (email, name[0], name[1] if len(name) > 1 else "-")
        )
        conn.commit()
    conn.close()

    session["email"] = email
    return redirect("/dashboard")

if __name__ == "__main__":
    app.run(debug=True)
